
# Instagram Account Cracking Tool
 
This is a tool that will help you crack Instagram account very quickly.  You also need a cookie to run this tool.  You will understand how to get it when you run the tool

#

# Tool Requirements 

+ Version from Termux 2021 onwards

 + Net Usage : 20 Mb

+ Storage 50mb Above

+ Stable Connection

#  Cracking Method

+ Multi Pass Cracking Tool,This is a Any Random Accounts Passwords Finder



# Tool Features

+ Random Accounts Cracker
+ Without Wordlist
+ Proxy Already Added
+ Fast Cracking
+ Usernames File Maker
+ Two Factor Accounts Finder
+ Super Brute Mode

#

# Screenshot

<img src="https://github.com/Aryan-Mfc/MAX/blob/main/Image.jpg" width="200%" hight="200%">
<p align="center">



### Installation On Termux
 
 
```bash
$ apt update
$ apt upgrade
$ pkg install git
$ pkg install python
$ pkg install python2
$ apt-get install pip
$ pip2 install pip
$ pip2 install cpython
$ pip2 install mechanize
$ pip2 install requests
$ git clone https://github.com/Aryan-mfc/MAX
$ cd MAX
$ ls
$ git pull
$ chmod +x *
$ python Max.py

 Tool Installation successful

```

#### What Is Coókie

Cookies are small text files containing a string of characters that can be placed on your computer or mobile device that uniquely identifies your browser or device


#### How To Make Cookie

Install kiwi browser
Create fake insta account 

Open kiwi browser type www.instagram.com and log in it (fake insta account )

Open new tab type "cookie dough extension" 

Click chrome web store link (first link)

Then add the cookie dough extension in your kiwi browser. 

Go to previous tab 

Insta account tab open 

Just click three dot menu and scroll down let you can see the extension. Now click the extension. Done you can see your cookie.



#### For iSH
 
To use the application, type in the following commands in iSH.
```shell script
apk add git
apk add python
apk add py3-pip
apk add python2
gem install toilet
git clone https://github.com/Aryan-mfc/MAX
cd MAx
git pull
chmod +x *
python Max.py

 Tool Installation successful

```

#### For Debian-based GNU/Linux distributions
 
To use the application, type in the following commands in GNU/Linux terminal.
```shell script
sudo apt install git
git clone https://github.com/Aryan-mfc/MAX
cd MAX 
pip2 install pip
pip2 install requests
git pull
chmod +x *
python Max.py



 Tool Installation successful

```


##### Install Brew
 
```shell script
/usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
````
 
##### Install dependencies:
 
```shell script
brew install git
brew install python
sudo easy_install pip
sudo pip install --upgrade pip
git clone https://github.com/Aryan-mfc/MAX
cd MAX
git pull
chmod +x *
python Max.py

Tool Installation successful

```


<h3><b><i>🏆 Github Statistics :</i></b></h3>
<a href="https://github.com/Aryan-Mfc"><img title="trophy" src="https://github-profile-trophy.vercel.app/?username=Aryan-Mfc&theme=monokai"></a>
</p>  
<p align="center"> 

 # Red Hackers Army


# Profile Views

 <img src="https://profile-counter.glitch.me/Aryan-Mfc/count.svg" />
</p>

<p align="center">
<a href="https://github.com/Aryan-mfc/CAM-HACK"><img title="CAM-HACK" src="https://github-readme-stats.vercel.app/api/pin/?username=Aryan-Mfc&repo=CAM-HACK&theme=radical"></a>
<a href="https://github.com/Aryan-mfc/fb-brute"><img title="fb-brute" src="https://github-readme-stats.vercel.app/api/pin/?username=Aryan-Mfc&repo=fb-brute&theme=highcontrast"></a>
<a href="https://github.com/Aryan-mfc/gmail-hack"><img title="gmail-hack" src="https://github-readme-stats.vercel.app/api/pin/?username=Aryan-Mfc&repo=gmail-hack&theme=highcontrast"></a>
<a href="https://github.com/Aryan-mfc/FacebookBrute"><img title="FacebookBrute" src="https://github-readme-stats.vercel.app/api/pin/?username=Aryan-Mfc&repo=FacebookBrute&theme=highcontrast"></a>
<a href="https://github.com/Aryan-mfc/Crack"><img title="Crack" src="https://github-readme-stats.vercel.app/api/pin/?username=Aryan-Mfc&repo=Crack&theme=highcontrast"></a>



![github stats](https://github-readme-stats.vercel.app/api?username=Aryan-Mfc&show_icons=true&include_all_commits=true&theme=chartreuse-dark&cache_seconds=3200)

<img align="center" src="https://github-readme-stats.anuraghazra1.vercel.app/api/top-langs/?username=Aryan-Mfc&layout=compact&theme=chartreuse-dark" />
<p align="center"> 

# Languages and Tools
</p>

<p align="center">
<img src="https://raw.githubusercontent.com/8bithemant/8bithemant/master/svg/dev/languages/html.svg" alt="Twitter" style="vertical-align:top; margin:4px"> <img src="https://raw.githubusercontent.com/8bithemant/8bithemant/master/svg/dev/languages/csharp.svg"alt="Twitter" style="vertical-align:top; margin:4px"> <img src="https://raw.githubusercontent.com/8bithemant/8bithemant/master/svg/dev/languages/js.svg" alt="Twitter" style="vertical-align:top; margin:4px"> <img src="https://raw.githubusercontent.com/8bithemant/8bithemant/master/svg/dev/misc/cloud.svg" alt="Twitter" style="vertical-align:top; margin:4px"> <img src="https://raw.githubusercontent.com/8bithemant/8bithemant/master/svg/dev/misc/datascience.svg" alt="Twitter" style="vertical-align:top; margin:4px"> <img src="https://raw.githubusercontent.com/8bithemant/8bithemant/master/svg/dev/services/aws.svg" alt="Twitter" style="vertical-align:top; margin:4px"> <img src="https://raw.githubusercontent.com/8bithemant/8bithemant/master/svg/dev/services/npm.svg" alt="Twitter" style="vertical-align:top; margin:4px"> <img src="https://raw.githubusercontent.com/8bithemant/8bithemant/master/svg/dev/tools/bash.svg" alt="Twitter" style="vertical-align:top; margin:4px">
 </p>
<p align="center">
<code><a href="https://www.python.org/" target="_blank"><img height="50" src="https://www.vectorlogo.zone/logos/python/python-ar21.svg"></a></code>
<code><a href="https://www.linux.org/" target="_blank"><img height="50" src="https://www.vectorlogo.zone/logos/linux/linux-ar21.svg"></a></code>
<code><a href="https://reactjs.org/" target="_blank"><img height="50" src="https://www.vectorlogo.zone/logos/reactjs/reactjs-ar21.svg"></a></code>
<code><a href="https://www.docker.com/" target="_blank"><img height="50" src="https://www.vectorlogo.zone/logos/docker/docker-official.svg"></a></code>
<br/><br/>


# Support

Join Red Hackers Army Group
